from sahi import AutoDetectionModel
from sahi.predict import get_sliced_prediction
import cv2
import numpy as np
import tempfile


class FastYOLOv8WithSahi:
    def __init__(self, model_path, conf_threshold=0.3, device="cuda:0"):
        self.model = AutoDetectionModel.from_pretrained(
            model_type="yolov8",
            model_path=model_path,
            confidence_threshold=conf_threshold,
            device=device,
        )
        # Оптимальные параметры для скорости (можно настроить)
        self.slice_size = 640  # уменьшили размер слайсов
        self.overlap_ratio = 0.1  # уменьшили перекрытие

    def predict(self, source, save_path="output.jpg"):
        # Если на вход подали numpy array
        if isinstance(source, np.ndarray):
            _, tmp_path = tempfile.mkstemp(suffix=".jpg")
            cv2.imwrite(tmp_path, source)
            source = tmp_path

        # Детекция с слайсингом
        result = get_sliced_prediction(
            source,
            self.model,
            slice_height=self.slice_size,
            slice_width=self.slice_size,
            overlap_height_ratio=self.overlap_ratio,
            overlap_width_ratio=self.overlap_ratio,
            postprocess_match_metric="IOU",
            postprocess_match_threshold=0.5,
            verbose=0  # отключаем вывод логов SAHI
        )

        # Загрузка оригинального изображения
        orig_img = cv2.imread(source)

        # Отрисовка результатов
        for pred in result.object_prediction_list:
            bbox = pred.bbox
            x1, y1, x2, y2 = int(bbox.minx), int(bbox.miny), int(bbox.maxx), int(bbox.maxy)
            conf = pred.score.value
            cv2.rectangle(orig_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(orig_img, f"{conf:.2f}", (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        # Сохранение
        cv2.imwrite(save_path, orig_img)

        return save_path